<?php

require_once('CarrieraLaureando.php');
require_once('GestoreConfigurazione.php');

class ProspettoPDFLaureando
{
    protected CarrieraLaureando $_carriera;
    protected FPDF $_PDF;
    protected int $_matricola;

    public function __construct($matricola, $CdL, $dataLaurea)
    {
        $this->_carriera = new CarrieraLaureando($matricola);
        $this->_matricola = $matricola;

        $this->_PDF = new FPDF();
        $this->_PDF->AddPage();
        $this->_PDF->SetFont("Arial", "", 12);
        $this->_PDF->Cell(0, 10, $CdL, 0, 0, "C");
        $this->_PDF->Ln(5);
        $this->_PDF->Cell(0, 10, "CARRIERA E SIMULAZIONE DEL VOTO DI LAUREA", 0, 0, "C");
        $this->_PDF->Ln(8);

        $this->printHeader($dataLaurea);

        $this->_PDF->SetFont("Arial", "", 10);
        foreach (["ESAME", "CFU", "VOT", "MED"] as $key => $col) {
            $this->_PDF->Cell($key == 0 ? 160 : 10, 6, $col, 1, $key == 3, "C");
        }
        $this->printBody();

        $this->printFooter($CdL);
    }

    private function printHeader($dataLaurea): void
    {
        $array = $this->_carriera->getHeader();
        $this->_PDF->Cell(190, 25, "", 1, 1);
        $this->_PDF->Ln(-25);
        $this->_PDF->SetFont("Arial", "", 10);
        $this->_PDF->Cell(50, 5, "Matricola:", 0, 0);
        $this->_PDF->Cell(50, 5, $this->_matricola, 0, 1);
        $this->_PDF->Cell(50, 5, "Nome:", 0, 0);
        $this->_PDF->Cell(50, 5, $array[0], 0, 1);
        $this->_PDF->Cell(50, 5, "Cognome:", 0, 0);
        $this->_PDF->Cell(50, 5, $array[1], 0, 1);
        $this->_PDF->Cell(50, 5, "Email:", 0, 0);
        $this->_PDF->Cell(50, 5, $array[2], 0, 1);
        $this->_PDF->Cell(50, 5, "Data:", 0, 0);
        $this->_PDF->Cell(50, 5, $dataLaurea, 0, 1);
        $this->_PDF->Ln(2);
    }

    private function printBody(): void
    {
        $this->_PDF->SetFont("Arial", "", 8);
        $heigth = 4;
        foreach ($this->_carriera->getBody() as $esame) {
            $this->_PDF->Cell(160, $heigth, $esame["nome"], 1, 0, "L");
            $this->_PDF->Cell(10, $heigth, $esame["peso"], 1, 0, "C");
            $this->_PDF->Cell(10, $heigth, $esame["voto"], 1, 0, "C");
            $this->_PDF->Cell(10, $heigth, $esame["faMedia"] ? "X" : " ", 1, 1, "C");
        }
        $this->_PDF->Ln(4);
    }

    private function printFooter($CdL): void
    {
        $array = $this->_carriera->getFooter();
        $config = GestoreConfigurazione::getConfig()->getParametri($CdL);
        $this->_PDF->Cell(190, 20, "", 1, 1);
        $this->_PDF->Ln(-20);
        $this->_PDF->SetFont("Arial", "", 10);
        $this->_PDF->Cell(80, 5, "Media Pesata (M):", 0, 0);
        $this->_PDF->Cell(80, 5, round($array[0], 3), 0, 1);
        $this->_PDF->Cell(80, 5, "Crediti che fanno media (CFU):", 0, 0);
        $this->_PDF->Cell(80, 5, $array[1], 0, 1);
        $this->_PDF->Cell(80, 5, "Crediti curriculari conseguiti:", 0, 0);
        $this->_PDF->Cell(80, 5, $array[2] . "/" . $config["CFUCurriculari"], 0, 1);
        $this->_PDF->Cell(80, 5, "Formula calcolo voto laurea:", 0, 0);
        $this->_PDF->Cell(80, 5, $config["formulaLaurea"], 0, 1);
    }

    public function genera(): void
    {
        $path = realpath(dirname(__FILE__)) . '/../prospetti';
        $this->_PDF->Output($path . "/" . $this->_matricola . ".pdf", "F");
    }

    public function getPDFLaureando(): FPDF
    {
        return $this->_PDF;
    }

    public function getMedia(): float
    {
        return $this->_carriera->getMedia();
    }

    public function getTestParams(): array
    {
        $res = $this->_carriera->getTestParams();
        $res["matricola"] = $this->_matricola;
        return $res;
    }
}