<?php

require_once('ProspettoPDFCommissione.php');
require_once('ProspettoPDFSimulazione.php');
require_once('ProspettoPDFLaureando.php');
require_once('ProspettoPDFLaureandoIngInf.php');

class GeneratoreProspetti
{

    public static function generaProspetti($matricole, $dataLaurea, $CdL): void
    {
        GeneratoreProspetti::dimenticaProspetti();

        $prospettoPDFCommissione = new ProspettoPDFCommissione($matricole, $CdL);
        if ($CdL == "T. Ing. Informatica") {    // gestiamo il caso particolare relativo al corso di IngInf
            foreach ($matricole as $mat) {
                $prospettoPDFLaureando = new ProspettoPDFLaureandoIngInf(
                    $mat, $dataLaurea
                );    // ProspettoPDFLaureandoIngInf non prevede l'inserimento di un CdL: è implicitamente ingegneria informatica
                $prospettoPDFSimulazione = new ProspettoPDFSimulazione($prospettoPDFLaureando, "T. Ing. Informatica");
                $prospettoPDFCommissione->appendiPagina($prospettoPDFSimulazione->getPage());
                $prospettoPDFLaureando->genera();
            }
        } else {    // gestiamo tutti gli altri possibili casi
            foreach ($matricole as $mat) {
                $prospettoPDFLaureando = new ProspettoPDFLaureando($mat, $CdL, $dataLaurea);
                $prospettoPDFSimulazione = new ProspettoPDFSimulazione($prospettoPDFLaureando, $CdL);
                $prospettoPDFCommissione->appendiPagina($prospettoPDFSimulazione->getPage());
                $prospettoPDFLaureando->genera();
            }
        }
        $prospettoPDFCommissione->genera();
    }

    private static function dimenticaProspetti(
    ): void    // utilizzata per pulire i vecchi prospetti generati: è requisito che i dati degli studenti non possono essere salvati tra sessioni diverse
    {
        $files = glob(realpath(dirname(__FILE__)) . '/../prospetti/*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
    }
}