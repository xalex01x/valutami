<?php

class GestoreConfigurazione
{
    private static ?GestoreConfigurazione $gestore = null;
    private array $_extracurriculari;
    private array $_informatici;
    private array $_parametri;     // anzichè memorizzare la lista, salviamo la stringa html da scrivere sull'interfaccia
    private string $_corsiDiLaurea;

    private function __construct()
    {
        $dati = json_decode(file_get_contents(__DIR__ . "/../config/config.json"), true);
        $this->_extracurriculari = $dati["esamiExtracurriculari"];
        $this->_informatici = $dati["esamiInformatici"];
        $this->_parametri = $dati["parametri"][0];
        $this->_corsiDiLaurea = "";
        foreach ($dati["corsiDiLaurea"] as $corso) {
            $this->_corsiDiLaurea .= "<option value = \"" . $corso . "\">" . $corso . "</option>";
        }
    }

    public static function getConfig(): GestoreConfigurazione
    {
        if (self::$gestore == null) {
            self::$gestore = new GestoreConfigurazione();
        }
        return self::$gestore;
    }

    public function isExtra($esame): bool
    {
        foreach ($this->_extracurriculari as $extra) {
            if ($extra == $esame) {
                return true;
            }
        }
        return false;
    }

    public function isInfo($esame): bool
    {
        foreach ($this->_informatici as $info) {
            if ($info == $esame) {
                return true;
            }
        }
        return false;
    }

    public function getCorsi(): string
    {
        return $this->_corsiDiLaurea;
    }

    public function getParametri($CdL): array
    {
        return $this->_parametri[$CdL];
    }
}