<?php

class GestoreAccessoProspetti
{
    public static function restituisciAccesso(): void
    {
        wp_redirect(home_url('/visualizzazione-pdf/'));
    }
}