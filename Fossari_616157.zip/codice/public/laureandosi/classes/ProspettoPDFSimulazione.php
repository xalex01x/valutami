<?php

require_once('GestoreConfigurazione.php');
require_once(__DIR__ . "/../lib/fpdf184/fpdf.php");

class ProspettoPDFSimulazione
{
    private FPDF $_prospettoLaureando;
    private string $_CdL;
    private float $_media;

    public function __construct($prospetto, $CdL)
    {
        $this->_prospettoLaureando = clone $prospetto->getPDFLaureando(
        );    // IMPORTANTE: necessario l'utilizzo della clone in quanto un semplice assegnamento copierebbe il valore del puntatore, non quello dei dati
        $this->_CdL = $CdL;
        $this->_media = $prospetto->getMedia();
        $this->calcolaSimulazione();
    }

    private function calcolaSimulazione(): void
    {
        $param = GestoreConfigurazione::getConfig()->getParametri($this->_CdL);
        $step = $param["Cstep"];
        $min = $param["Cmin"];
        $max = $param["Cmax"];
        $header = "VOTO COMMISSIONE (C)";
        if ($step == 0) {
            $step = $param["Tstep"];
            $min = $param["Tmin"];
            $max = $param["Tmax"];
            $header = "VOTO TESI (T)";
        }
        $expr = $param["formulaLaureaCalcolo"];
        $this->_prospettoLaureando->Ln(3);
        $this->_prospettoLaureando->SetFont("Arial", "", 10);
        $this->_prospettoLaureando->Cell(190, 6, "SIMULAZIONE DI VOTO DI LAUREA", 1, 1, "C");

        $array = null;
        for ($i = 0; $min + $i * $step <= $max; $i += $step) {
            $elem["key"] = $min + $i * $step;
            if ($param["Cstep"] == 0) {
                $T = $elem["key"];
                $C = 0;
            } else {
                $T = 0;
                $C = $elem["key"];
            }
            $formula = str_replace(['$M', '$T', '$C', '$F'], [$this->_media, $T, $C, $param["CFUCurriculari"]], $expr);
            $result = 0;
            eval ("\$result = $formula;");
            $elem["value"] = round($result, 3);
            $array[] = $elem;
        }

        $width = 95;    // due celle per riga
        $cols = 1;
        $mid = 0;
        if (sizeof($array) > 7) {    // se esistono più di 7 elementi nell'array allora usa quattro colonne
            $width = 47.5;
            if (sizeof(
                    $array
                ) % 2 == 0) { // se i possibili valori del risultato sono in numero pari o dispari ordina a dovere le righe della tabella di simulazione
                $mid = sizeof($array) / 2;
            } else {
                $mid = floor(sizeof($array) / 2) + 1;
            }
            $cols = 2;
            $this->_prospettoLaureando->Cell($width, 6, $header, 1, 0, "C");
            $this->_prospettoLaureando->Cell($width, 6, "VOTO LAUREA", 1, 0, "C");
        }
        $this->_prospettoLaureando->Cell($width, 6, $header, 1, 0, "C");
        $this->_prospettoLaureando->Cell($width, 6, "VOTO LAUREA", 1, 1, "C");
        $iter = 0;
        while ($iter < sizeof($array)) {
            $elem = $array[$iter];
            $this->_prospettoLaureando->Cell($width, 6, $elem["key"], 1, 0, "C");
            $this->_prospettoLaureando->Cell($width, 6, $elem["value"], 1, 0, "C");
            if ($cols == 2 && isset($array[$iter + $mid])) {
                $elem = $array[$iter + $mid];
                $this->_prospettoLaureando->Cell($width, 6, $elem["key"], 1, 0, "C");
                $this->_prospettoLaureando->Cell($width, 6, $elem["value"], 1, 1, "C");
            } else {
                $this->_prospettoLaureando->Ln();
            }
            $iter++;
            if ($cols == 2 && $iter == $mid) {
                break;
            }
        }
        $this->_prospettoLaureando->Ln();
        $this->_prospettoLaureando->SetFillColor(255, 255, 255);
        $this->_prospettoLaureando->MultiCell(190, 5, $param["MessaggioCommissione"], 0, 0, "L");
    }

    public function getPage(): FPDF
    {
        return $this->_prospettoLaureando;
    }
}