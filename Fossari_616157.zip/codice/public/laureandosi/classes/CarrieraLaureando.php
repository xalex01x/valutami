<?php

require_once('EsameLaureando.php');
require_once('GestioneCarrieraStudente.php');
require_once(__DIR__ . '/../lib/fpdf184/fpdf.php');

class CarrieraLaureando
{
    protected array $_esami;
    private string $_nome;
    private string $_cognome;
    private string $_email;
    private float $_media;
    private int $_CFUTot;
    private int $_CFUMedia;

    public function __construct($matricola)
    {
        $dati = GestioneCarrieraStudente::getAnagrafica($matricola);
        $this->_nome = $dati["nome"];
        $this->_cognome = $dati["cognome"];
        $this->_email = $dati["email_ate"];

        $this->_esami = GestioneCarrieraStudente::getCarriera($matricola);
        $this->calcolaCFUTotali();
        $this->calcolaMedia();    // chiamata inutilmente se il corso è ingegneria informatica
    }

    private function calcolaCFUTotali(): void
    {
        $this->_CFUTot = 0;
        foreach ($this->_esami as $esame) {
            $this->_CFUTot += $esame->getPeso();
        }
    }

    protected function calcolaMedia(): void
    {    // non si può fare nel costruttore: non è ancora possibile stabilire se il laureando può ottenere il bonus. Va prima calcolato quest'ultimo e solo dopo calcolata la media
        $this->_CFUMedia = 0;
        $this->_media = 0.0;    // necessario perchè potrebbe essere ricalcolata
        foreach ($this->_esami as $esame) {
            if ($esame->faMedia()) {
                $this->_CFUMedia += $esame->getPeso();
                $this->_media += ($esame->getVoto() * $esame->getPeso());
            }
        }
        $this->_media = $this->_media /= $this->_CFUMedia;    // l'arrotondamento lo effettuo alla stampa della media perchè facendolo qui ottengo risultati inconsistenti
    }

    public function getHeader(): array
    {
        return [$this->_nome, $this->_cognome, $this->_email];
    }

    public function getBody(): array
    {
        $res = array();
        foreach ($this->_esami as $esame) {
            $elem = array();
            $elem["nome"] = $esame->getNome();
            $elem["peso"] = $esame->getPeso();
            $elem["voto"] = $esame->getVoto();
            $elem["faMedia"] = $esame->faMedia();
            $res[] = $elem;
        }
        return $res;
    }

    public function getFooter(): array
    {
        return [$this->_media, $this->_CFUMedia, $this->_CFUTot];
    }

    public function getMedia(): float
    {
        return $this->_media;
    }

    public function getTestparams(): array
    {
        $res["nome"] = $this->_nome;
        $res["cognome"] = $this->_cognome;
        $res["email"] = $this->_email;
        $res["media"] = round($this->_media, 3);
        $res["CFUTot"] = $this->_CFUTot;
        $res["CFUMedia"] = $this->_CFUMedia;
        return $res;
    }
}