<?php

require_once("GestoreInvioProspetti.php");
require_once("GeneratoreProspetti.php");
require_once("GestoreAccessoProspetti.php");

class InterfacciaUtente
{

    public static function generaProspetto($matricole, $data, $CdL): void
    {
        GeneratoreProspetti::generaProspetti($matricole, $data, $CdL);
    }

    public static function inviaProspetto($matricole, &$res): void
    {
        GestoreInvioProspetti::inviaProspetti($matricole, $res);
    }

    public static function accediProspetto(): void
    {
        GestoreAccessoProspetti::restituisciAccesso();
    }

    public static function setMessage($message, &$res): void
    {
        $res = $message;
    }
}