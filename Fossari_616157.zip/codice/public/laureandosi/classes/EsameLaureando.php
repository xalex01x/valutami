<?php

class EsameLaureando
{
    private string $_nome;
    private int $_voto;
    private DateTime $_data;
    private int $_CFU;
    private bool $_informatico;
    private bool $_extracurriculare;
    private bool $_faMedia;

    public function __construct($nome, $voto, $data, $peso, $media)
    {
        $this->_nome = $nome;
        $this->_voto = $voto;
        $this->_data = $data;
        $this->_CFU = $peso;
        $this->_faMedia = $media;

        $gestore = GestoreConfigurazione::getConfig();
        $this->_informatico = $gestore->isInfo($nome);
        $this->_extracurriculare = $gestore->isExtra($nome);
    }

    public function isInfo(): bool
    {
        return $this->_informatico;
    }

    public function isExtra(): bool
    {
        return $this->_extracurriculare;
    }

    public function faMedia(): bool
    {
        return $this->_faMedia;
    }

    public function getPeso(): int
    {
        return $this->_CFU;
    }

    public function getVoto(): int
    {
        return $this->_voto;
    }

    public function setBonus(): void
    {
        $this->_faMedia = false;
    }

    public function getNome(): string
    {
        return $this->_nome;
    }

    public function getDate(): DateTime
    {
        return $this->_data;
    }
}