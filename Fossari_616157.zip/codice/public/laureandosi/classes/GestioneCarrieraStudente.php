<?php

require_once('EsameLaureando.php');

class GestioneCarrieraStudente
{
    private static string $path = __DIR__ . "/../studentData";

    public static function getAnagrafica($matricola): array
    {
        return json_decode(
            file_get_contents(self::$path . "/" . $matricola . "_anagrafica.json"),
            true
        )["Entries"]["Entry"];
    }

    public static function getCarriera($matricola): array
    {
        $dati = json_decode(file_get_contents(self::$path . "/" . $matricola . "_esami.json"), true)["Esami"]["Esame"];
        $res = null;
        foreach ($dati as $esame) {
            if (self::esameValido($esame)) {
                continue;
            }
            $res[] = (new EsameLaureando(
                $esame["DES"],
                self::votoNumerico($esame["VOTO"]),
                DateTime::createFromFormat('d/m/Y', $esame["DATA_ESAME"]),
                $esame["PESO"],
                $esame["VOTO"] != null
            ));
        }
        usort($res, function ($a, $b) {
            return $a->getDate() > $b->getDate();
        });
        return $res;
    }

    private static function esameValido($esame
    ): bool    // riconosce se l'esame è da includere nella carriera di uno studente
    {
        // un esame è valido se ha dei CFU, non è sovrannumerario o non si tratta della prova finale
        return !is_int($esame["PESO"]) || $esame["SOVRAN_FLG"] != 0 || $esame["DES"] == "PROVA FINALE";
    }

    private static function votoNumerico($voto): int   // covnerte la stringa "VOTO" in un intero
    {
        if (!isset($voto)) {
            return 0;
        }
        if ($voto == "30  e lode") {
            return 33;
        }
        return (int)$voto;
    }

    public static function bonusEligible($matricola): bool
    {
        /* la differenza tra la data di chisura e l'1/09 dell'anno di immatricolazione deve essere meno di 3 anni e 6 mesi */
        $dati = json_decode(
            file_get_contents(self::$path . "/" . $matricola . "_esami.json"),
            true
        )["Esami"]["Esame"][0];
        $data1 = DateTime::createFromFormat('d/m/Y', $dati["INIZIO_CARRIERA"]);
        $data1->setDate((int)$data1->format('Y'), 9, 1);    // la data di imamtricolazione è 1/9/ANNO_INIZIO
        $data2 = DateTime::createFromFormat('d/m/Y', $dati["DATA_CHIUSURA"]);    // la data di chiusara è
        return date_diff($data1, $data2)->days < 1277;        // 3 anni e 6 mesi in giorni
    }
}