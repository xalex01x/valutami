<?php

require_once("InterfacciaUtente.php");
require_once("GestioneCarrieraStudente.php");
require_once(__DIR__ . "/../lib/PHPMailer/src/PHPMailer.php");
require_once(__DIR__ . "/../lib/PHPMailer/src/SMTP.php");
require_once(__DIR__ . "/../lib/PHPMailer/src/Exception.php");

use PHPMailer\PHPMailer\PHPMailer;

class GestoreInvioProspetti
{
    public static function inviaProspetti($matricole, &$res): void
    {
        foreach ($matricole as $key => $m) {
            $addr = GestioneCarrieraStudente::getAnagrafica($m)["email_ate"];
            if (self::inviaMail($m, $addr)) {
                InterfacciaUtente::setMessage("Prospetti inviati.", $res);
            } else {
                InterfacciaUtente::setMessage("Errore durante invio " . ($key + 1) . "/" . sizeof($matricole), $res);
                break;
            }
        }
    }

    private static function inviaMail($matricola, $addr): bool
    {
        $mex = new PHPMailer();
        $mex->IsSMTP();
        $mex->Host = "mixer.unipi.it";
        $mex->SMTPSecure = "tls";
        $mex->SMTPAuth = false;
        $mex->Port = 25;
        try {
            $mex->From = "noreply-laureandosi@dii.unipi.it";

            // a chi inviare la mail. per testare il caso d'uso ho utilizzato la mia mail
            $testing = true;
            ($testing) ? $mex->addAddress("a.fossari@studenti.unipi.it") : $mex->addAddress($addr);

            $mex->addAttachment(__DIR__ . "/../prospetti/" . $matricola . ".pdf");
            $mex->Subject = "Appello di laurea in Ing. TEST - indicatori per voto di laurea";
            $mex->Body = "Gentile laureando/laureanda,\n" .
                "Allego un prospetto contenente: la sua carriera, gli indicatori e la formula che la commissione adoperera' per determinare il voto di laurea.\n" .
                "La prego di prendere visione dei dati relativi agli esami.\n" .
                "In caso di dubbi scrivere a: vittoria.dattilo@unipi.it\n\n" .
                "Alcune spiegazioni:\n" .
                "- gli esami che non hanno un voto in trentesimi, hanno voto nominale zero al posto di giudizio o idoneità, in quanto non contribuiscono al calcolo della media ma solo al numero di crediti curriculari;\n" .
                "- gli esami che non fanno media (pur contribuendo ai crediti curriculari) non hanno la spunta nella colonna MED;\n" .
                "- il voto di tesi (T) appare nominalmente a zero in quanto verrà determinato in sede di laurea, e va da 18 a 30.\n" .
                "Cordiali saluti\n" .
                "Unita' Didattica DII";
            $res = $mex->Send();
        } catch (Exception $e) {
            $res = false;
        }
        $mex->SmtpClose();
        unset($mex);
        return $res;
    }
}