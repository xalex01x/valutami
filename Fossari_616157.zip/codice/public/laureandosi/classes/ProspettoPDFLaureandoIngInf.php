<?php

require_once('CarrieraLaureandoIngInf.php');
require_once('ProspettoPDFLaureando.php');
require_once('GestoreConfigurazione.php');

class ProspettoPDFLaureandoIngInf extends ProspettoPDFLaureando
{
    public function __construct($matricola, $dataLaurea)
    {
        $this->_carriera = new CarrieraLaureandoIngInf($matricola);
        $this->_matricola = $matricola;
        $CdL = "T. Ing. Informatica";

        $this->_PDF = new FPDF();
        $this->_PDF->AddPage();
        $this->_PDF->SetFont("Arial", "", 12);
        $this->_PDF->Cell(0, 10, $CdL, 0, 0, "C");
        $this->_PDF->Ln(5);
        $this->_PDF->Cell(0, 10, "CARRIERA E SIMULAZIONE DEL VOTO DI LAUREA", 0, 0, "C");
        $this->_PDF->Ln(8);

        $this->printHeader($dataLaurea);

        $this->_PDF->SetFont("Arial", "", 10);
        foreach (["ESAME", "CFU", "VOT", "MED", "INF"] as $key => $col) {
            $this->_PDF->Cell($key == 0 ? 150 : 10, 6, $col, 1, $key == 4, "C");
        }
        $this->printBody();

        $this->printFooter($CdL);
    }

    private function printHeader($dataLaurea): void
    {
        $array = $this->_carriera->getHeader();
        $this->_PDF->Cell(190, 30, "", 1, 1);
        $this->_PDF->Ln(-30);
        $this->_PDF->SetFont("Arial", "", 10);
        $this->_PDF->Cell(50, 5, "Matricola:", 0, 0);
        $this->_PDF->Cell(50, 5, $this->_matricola, 0, 1);
        $this->_PDF->Cell(50, 5, "Nome:", 0, 0);
        $this->_PDF->Cell(50, 5, $array[0], 0, 1);
        $this->_PDF->Cell(50, 5, "Cognome:", 0, 0);
        $this->_PDF->Cell(50, 5, $array[1], 0, 1);
        $this->_PDF->Cell(50, 5, "Email:", 0, 0);
        $this->_PDF->Cell(50, 5, $array[2], 0, 1);
        $this->_PDF->Cell(50, 5, "Data:", 0, 0);
        $this->_PDF->Cell(50, 5, $dataLaurea, 0, 1);
        $this->_PDF->Cell(50, 5, "Bonus:", 0, 0);
        $this->_PDF->Cell(50, 5, $array[3], 0, 1);
        $this->_PDF->Ln(2);
    }

    private function printBody(): void
    {
        $this->_PDF->SetFont("Arial", "", 8);
        $heigth = 4;
        foreach ($this->_carriera->getBody() as $esame) {
            $this->_PDF->Cell(150, $heigth, $esame["nome"], 1, 0, "L");
            $this->_PDF->Cell(10, $heigth, $esame["peso"], 1, 0, "C");
            $this->_PDF->Cell(10, $heigth, $esame["voto"], 1, 0, "C");
            $this->_PDF->Cell(10, $heigth, $esame["faMedia"] ? "X" : " ", 1, 0, "C");
            $this->_PDF->Cell(10, $heigth, $esame["info"] ? "X" : " ", 1, 1, "C");
        }
        $this->_PDF->Ln(4);
    }

    private function printFooter($CdL): void
    {
        $array = $this->_carriera->getFooter();
        $config = GestoreConfigurazione::getConfig()->getParametri($CdL);
        $this->_PDF->Cell(190, 30, "", 1, 1);
        $this->_PDF->Ln(-30);
        $this->_PDF->SetFont("Arial", "", 10);
        $this->_PDF->Cell(80, 5, "Media Pesata (M):", 0, 0);
        $this->_PDF->Cell(80, 5, round($array[0], 3), 0, 1);
        $this->_PDF->Cell(80, 5, "Crediti che fanno media (CFU):", 0, 0);
        $this->_PDF->Cell(80, 5, $array[1], 0, 1);
        $this->_PDF->Cell(80, 5, "Crediti curriculari conseguiti:", 0, 0);
        $this->_PDF->Cell(80, 5, $array[2] . "/" . $config["CFUCurriculari"], 0, 1);
        $this->_PDF->Cell(80, 5, "Voto di tesi (T):", 0, 0);
        $this->_PDF->Cell(80, 5, "0", 0, 1);
        $this->_PDF->Cell(80, 5, "Formula calcolo voto laurea:", 0, 0);
        $this->_PDF->Cell(80, 5, $config["formulaLaurea"], 0, 1);
        $this->_PDF->Cell(80, 5, "Media pesata esami INF:", 0, 0);
        $this->_PDF->Cell(80, 5, round($array[3], 3), 0, 1);
    }
}