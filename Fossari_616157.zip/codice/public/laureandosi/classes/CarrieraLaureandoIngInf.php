<?php

require_once('CarrieraLaureando.php');

class CarrieraLaureandoIngInf extends CarrieraLaureando
{
    private float $_mediaInfo;
    private ?string $bonus = null;     // il bonus può restare nullo

    public function __construct($matricola)
    {
        parent::__construct($matricola);
        if (GestioneCarrieraStudente::bonusEligible($matricola)) {
            $this->trovaBonus();
            parent::calcolaMedia();        // ricalcoliamo la media generale dopo aver stabilito che il bonus è valido
        }
        $this->calcolaMediaInfo();
    }

    private function trovaBonus(): void
    {
        $esameBonus = null;
        foreach ($this->_esami as $esame) {
            if ($esameBonus == null || ($esameBonus->getVoto() > $esame->getVoto() && $esame->faMedia(
                    )) || ($esameBonus->getVoto() == $esame->getVoto() && $esameBonus->getPeso() < $esame->getPeso())) {
                $esameBonus = $esame;
            }
        }
        $esameBonus->setBonus();
        $this->bonus = $esameBonus->getNome();
    }

    private function calcolaMediaInfo(): void
    {
        $iter = 0;
        $this->_mediaInfo = 0.0;
        foreach ($this->_esami as $esame) {
            if ($esame->isInfo() && $esame->faMedia()) {
                $this->_mediaInfo += ($esame->getVoto() * $esame->getPeso());
                $iter += $esame->getPeso();
            }
        }
        $this->_mediaInfo = $this->_mediaInfo /= $iter;
    }

    public function getHeader(): array
    {
        $res = parent::getHeader();
        $res[] = isset($this->bonus) ? "SI" : "NO";
        return $res;
    }

    public function getBody(): array
    {
        $res = array();
        foreach ($this->_esami as $esame) {
            $elem = array();
            $elem["nome"] = $esame->getNome();
            $elem["peso"] = $esame->getPeso();
            $elem["voto"] = $esame->getVoto();
            $elem["faMedia"] = $esame->faMedia();
            $elem["info"] = $esame->isInfo();
            $res[] = $elem;
        }
        return $res;
    }

    public function getFooter(): array
    {
        $res = parent::getFooter();
        $res[] = $this->_mediaInfo;
        return $res;
    }

    public function getTestparams(): array
    {
        $res = parent::getTestParams();
        $res["bonus"] = $this->bonus;
        $res["bonus"] = (isset($res["bonus"]) ? $res["bonus"] : "NO");
        $res["mediaInfo"] = round($this->_mediaInfo, 3);
        return $res;
    }
}