<?php

require_once('ProspettoPDFSimulazione.php');
require_once('GestioneCarrieraStudente.php');
require_once(__DIR__ . '/../lib/fpdf184/fpdf.php');

// il require seguente fa rimento ad uno script costruito per FPDF che consente di concatenare più documenti tra loro
// source: https://www.fpdf.org/en/script/dl.php?id=94&f=zip
require_once(__DIR__ . '/../lib/fpdf_merge/fpdf_merge.php');

class ProspettoPDFCommissione
{
    private array $_matricole;
    private string $_CdL;
    private array $_pagine;

    public function __construct($matricole, $CdL)
    {
        $this->_matricole = $matricole;
        $this->_CdL = $CdL;
        $this->_pagine = array();
        $this->creaPrimaPagina();
    }

    private function creaPrimaPagina(): void
    {
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont("Arial", "", 10);
        $pdf->Cell(0, 10, $this->_CdL, 0, 0, "C");
        $pdf->Ln(8);
        $pdf->Cell(
            0,
            10,
            "LAUREANDOSI 2 - Progettazione: mario.cimino@unipi.it, Amministrazione: rose.rossiello@unipi.it",
            0,
            0,
            "C"
        );
        $pdf->Ln(8);
        $pdf->Cell(0, 10, "LISTA LAUREANDI", 0, 0, "C");
        $pdf->Ln(8);
        $pdf->SetFont("Arial", "", 10);
        $width = 47.5;
        foreach (["COGNOME", "NOME", "CDL", "VOTO LAUREA"] as $key => $col) {
            $pdf->Cell($width, 6, $col, 1, $key == 3, "C");
        }
        $pdf->SetFont("Arial", "", 8);
        foreach ($this->_matricole as $m) {
            $dati = GestioneCarrieraStudente::getAnagrafica($m);
            $pdf->Cell($width, 5, $dati["nome"], 1, 0, "C");
            $pdf->Cell($width, 5, $dati["cognome"], 1, 0, "C");
            $pdf->Cell($width, 5, "", 1, 0, "C");
            $pdf->Cell($width, 5, "/110", 1, 1, "C");
        }
        $this->_pagine[0] = $pdf;
    }

    public function genera(): void
    {
        $path = realpath(dirname(__FILE__)) . '/../prospetti';
        foreach ($this->_pagine as $key => $page) {
            if ($key) {
                $merge = new FPDF_merge();
                $merge->add($path . "/commissione.pdf");
                $this->_pagine[$key]->Output($path . "/tmp.pdf", "F");
                $merge->add($path . "/tmp.pdf");
                $merge->output($path . "/commissione.pdf");
            } else {
                $this->_pagine[$key]->Output($path . "/commissione.pdf", "F");
            }
        }
        if (isset($this->_pagine[1])) {
            unlink($path . "/tmp.pdf");
        }
    }

    public function appendiPagina($prospetto): void
    {
        $this->_pagine[] = $prospetto;
    }
}