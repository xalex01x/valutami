<?php

require_once(__DIR__ . '/classes/GestoreConfigurazione.php');
require_once(__DIR__ . '/classes/InterfacciaUtente.php');

$risultatiInvio = "";   // stringa dove inserire i risultati di un invio di prospetti

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"])) {
    switch ($_POST["action"]) {
        case "GeneraProspetti":
            InterfacciaUtente::GeneraProspetto(
                explode(' ', $_POST["laureandi"]),
                $_POST["data"],
                $_POST["CdL"]
            );   // lista delle matricole, data laurea e corso di laurea
            break;
        case "AccediProspetti":
            InterfacciaUtente::AccediProspetto();   // senza argomenti: deve solo ritornare il path
            break;
        case "InviaProspetti":
            InterfacciaUtente::InviaProspetto(
                explode(' ', $_POST["laureandi"]),
                $risultatiInvio
            );  // $risultatiInvio viene utilizzato come riferimento per il messaggio
            break;

        default:
            echo "<p>Azione non riconosciuta.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang='it'>

<head>
    <title>Laureandosi2</title>
    <style>
        body {
            margin: auto;
            padding: 5vh;
            width: 100vh;
        }

        #title {
            font-family: "Calibri", serif;
            font-size: 20pt;
            color: #0001CD;
            font-weight: 700;
            text-align: center;
        }

        .text {
            color: #0001CD;
            font-size: 13pt;
            font-weight: 700;
            text-align: center;
            font-family: "Times New Roman", Times, serif;
        }

        #rettangolo {
            background-color: #C8E1F1;
            border: solid 1px #4E55B2;
            height: 500px;
        }

        #centro {
            display: flex;
            justify-content: space-between;
            height: 30vh;
        }

        .spacer {
            height: 2vh;
        }

        #center,
        #left,
        #right {
            padding: 3vh;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        #right, #left {
            width: 20%;
        }

        .field {
            width: 100%;
        }

        .field > label {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .field > select {
            width: 100%;
            height: 3vh;
        }

        .date {
            width: 100%;
            height: 5vh;
            background-color: #B0E0E6;
        }

        .bordato {
            border: solid 2px #4E55B2;
        }

        .colSpacer {
            flex-grow: 1;
        }

        .textarea {
            width: 100%;
            height: 100%;
        }

        .button {
            border: #0073AA;
            background-color: #0073AA;
            color: #FFFFFF;
            font-size: 15pt;
            font-family: "Calibri", serif;
            border-radius: 6px;
            width: 100%;
            height: 5vh;
            text-align: center;
        }

        .accesso {
            background: none;
            border: none;
            color: #0073AA;
            text-decoration: underline;
            display: flex;
            justify-content: center;
            width: 100%;
        }

        #risultatiInvio {
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>

<body>
<div id="rettangolo">
    <form method="POST" action="index.php">
        <p id="title">Laureandosi 2 - Gestione Lauree</p>
        <div class="spacer"></div>
        <div id="centro">
            <div id="left">
                <div class="field">
                    <label for="CdL" class="text">Cdl:</label>
                    <select id="CdL" name="CdL" class="bordato">
                        <?php
                        echo "<option disabled selected>Seleziona Cdl</option>" . GestoreConfigurazione::getConfig(
                            )->getCorsi();
                        ?>
                    </select>
                </div>
                <div class="colSpacer"></div>
                <div class="field">
                    <label for="data" class="text">Data Laurea:</label>
                    <input id="data" type="date" class="date bordato" name="data"/>
                </div>
            </div>
            <div id="center">
                <div class="field colSpacer">
                    <label for="textarea" class="text">Matricole:</label>
                    <textarea id="textarea" class="bordato textarea" name="laureandi"></textarea>
                </div>
            </div>
            <div id="right">
                <div class="field">
                    <button class="button" type="submit" name="action" value="GeneraProspetti">Crea
                        Prospetti
                    </button>
                </div>
                <div class="colSpacer"></div>
                <div class="field">
                    <button class="accesso text" type="submit" name="action" value="AccediProspetti">apri
                        prospetti
                    </button>
                </div>
                <div class="colSpacer"></div>
                <div>
                    <div class="field">
                        <button class="button" type="submit" name="action" value="InviaProspetti">Invia
                            Prospetti
                        </button>
                        <p id="risultatiInvio" style="color: red;"><?php
                            echo $risultatiInvio; ?></p>
                    </div>
                </div>
            </div>
    </form>
</div>
</body>

</html>