<?php

require_once(__DIR__ . "/../classes/ProspettoPDFLaureando.php");
require_once(__DIR__ . "/../classes/ProspettoPDFLaureandoIngInf.php");
require_once(__DIR__ . "/../classes/ProspettoPDFSimulazione.php");
session_start();

class Test
{
    public static function test(): void
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $prospettoL = null;
            $matricola = $_POST["matricola"];
            $_SESSION["matricola"] = $matricola;
            $data = $_POST["data"];
            $CdL = $_POST["CdL"];
            $prospettoL = null;

            if ($CdL == "T. Ing. Informatica") {
                $prospettoL = new ProspettoPDFLaureandoIngInf($matricola, $data);
            } else {
                $prospettoL = new ProspettoPDFLaureando($matricola, $CdL, $data);
            }

            $prospettoS = new ProspettoPDFSimulazione($prospettoL, $CdL);
            $res = $prospettoL->getTestParams();
            $prospettoS->getPage()->Output(ABSPATH . "laureandosi/test/risultati/" . $matricola . ".pdf", "F");

            $trueValues = json_decode(file_get_contents(ABSPATH . "laureandosi/test/oracolo.json"), true)[$matricola];

            $_SESSION["result"] = "";
            foreach ($res as $key => $val) {
                $_SESSION["result"] .= "<tr class=\"" . ($trueValues[$key] === $val ? "green" : "red") . "\"><td>" . $key . "</td><td>" . $val . "</td><td>" . $trueValues[$key] . "</td></tr>";
            }
            wp_redirect(home_url('/test/'));
            exit;
        }
    }
}