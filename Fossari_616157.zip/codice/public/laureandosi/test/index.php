<?php

require_once(__DIR__ . "/../classes/GestoreConfigurazione.php");
require_once(__DIR__ . "/Test.php");
session_start();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    Test::test();
}
?>

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prospetto Laureando</title>
    <style>
        .red {
            border: solid 1px black;
            color: red;
        }

        .green {
            border: solid 1px black;
            color: green;
        }

        table {
            border: solid 1px black;
            border-collapse: collapse;
        }

        input,
        button {
            margin: 10px;
        }

        td {
            border: solid 1px black;
            width: 30vh;
            font-size: 2vh;
            text-align: center;
        }

        .central {
            display: flex;
            justify-content: space-evenly;
            width: 100%;
        }

        .text {
            text-align: center;
            font-size: 4vh;
            font-weight: bolder;
            width: 50%;
        }
    </style>
</head>

<div class="central">
    <form action="<?php
    echo get_permalink(); ?>" method="POST">
        <input name="matricola" placeholder="inserisci una matricola" required>
        <input name="data" type="date" required>
        <select name="CdL">
            <?php
            echo "<option disabled selected>Seleziona Cdl</option>" . GestoreConfigurazione::getConfig()->getCorsi();
            ?>
        </select>
        <button type="submit">Testa prospetto</button>
    </form>
</div>
<?php
if (isset($_SESSION["result"])) {
    echo "<div class = \"central\"><table><tr><th>Parametro</th><th>Generato</th><th>Previsto</th></tr>" . $_SESSION["result"] . "</table></div>";
    echo "<br><div>" .
        "<div class = \"central\"><div class = \"text\">PDF generato</div><div class = \"text\">PDF oracolo</div></div>" .
        "<iframe src=\"" . esc_url(
            home_url('/laureandosi/test/risultati/' . $_SESSION["matricola"] . ".pdf")
        ) . "\" width=\"50%\" height=\"1000px\" style=\"border: none;\"></iframe>" .
        "<iframe src=\"" . esc_url(
            home_url('/laureandosi/test/references/' . $_SESSION["matricola"] . "_output.pdf")
        ) . "\" width=\"50%\" height=\"1000px\" style=\"border: none;\"></iframe>" .
        "</div>";
    unset($_SESSION["result"]);
}
?>
</body>
</html>